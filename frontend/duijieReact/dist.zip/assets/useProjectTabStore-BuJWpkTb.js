import{c as n,F as s,a7 as p,a8 as h,a4 as d,K as m,a9 as u,aa as f,ab as x}from"./index-BSLJZjOw.js";import{B as M}from"./briefcase-BOSnRoTq.js";import{Z as g}from"./zap-Xm5V0vzX.js";import{c as C}from"./vendor-ui-BQaEbHCt.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=n("CodeXml",[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=n("Coffee",[["path",{d:"M10 2v2",key:"7u0qdc"}],["path",{d:"M14 2v2",key:"6buw04"}],["path",{d:"M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1",key:"pwadti"}],["path",{d:"M6 2v2",key:"colzsn"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=n("Cpu",[["rect",{width:"16",height:"16",x:"4",y:"4",rx:"2",key:"14l7u7"}],["rect",{width:"6",height:"6",x:"9",y:"9",rx:"1",key:"5aljv4"}],["path",{d:"M15 2v2",key:"13l42r"}],["path",{d:"M15 20v2",key:"15mkzm"}],["path",{d:"M2 15h2",key:"1gxd5l"}],["path",{d:"M2 9h2",key:"1bbxkp"}],["path",{d:"M20 15h2",key:"19e6y8"}],["path",{d:"M20 9h2",key:"19tzq7"}],["path",{d:"M9 2v2",key:"165o2o"}],["path",{d:"M9 20v2",key:"i2bqo8"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const H=n("Gamepad2",[["line",{x1:"6",x2:"10",y1:"11",y2:"11",key:"1gktln"}],["line",{x1:"8",x2:"8",y1:"9",y2:"13",key:"qnk9ow"}],["line",{x1:"15",x2:"15.01",y1:"12",y2:"12",key:"krot7o"}],["line",{x1:"18",x2:"18.01",y1:"10",y2:"10",key:"1lcuu1"}],["path",{d:"M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",key:"mfqc10"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const I=n("Heart",[["path",{d:"M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z",key:"c3ymky"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=n("Lightbulb",[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",key:"1gvzjb"}],["path",{d:"M9 18h6",key:"x1upvd"}],["path",{d:"M10 22h4",key:"ceow96"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const q=n("Music",[["path",{d:"M9 18V5l12-2v13",key:"1jmyc2"}],["circle",{cx:"6",cy:"18",r:"3",key:"fqmcym"}],["circle",{cx:"18",cy:"16",r:"3",key:"1hluhg"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=n("ShoppingCart",[["circle",{cx:"8",cy:"21",r:"1",key:"jimo8o"}],["circle",{cx:"19",cy:"21",r:"1",key:"13723u"}],["path",{d:"M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",key:"9zh506"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=n("Target",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["circle",{cx:"12",cy:"12",r:"6",key:"1vlfrh"}],["circle",{cx:"12",cy:"12",r:"2",key:"1c9p78"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=n("Trophy",[["path",{d:"M6 9H4.5a2.5 2.5 0 0 1 0-5H6",key:"17hqa7"}],["path",{d:"M18 9h1.5a2.5 2.5 0 0 0 0-5H18",key:"lmptdp"}],["path",{d:"M4 22h16",key:"57wxv0"}],["path",{d:"M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22",key:"1nw9bq"}],["path",{d:"M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22",key:"1np0yb"}],["path",{d:"M18 2H6v7a6 6 0 0 0 12 0V2Z",key:"u46fv3"}]]),B=[{key:"FolderKanban",icon:s,label:"项目"},{key:"Briefcase",icon:M,label:"商务"},{key:"Code2",icon:v,label:"开发"},{key:"ShoppingCart",icon:w,label:"电商"},{key:"Palette",icon:p,label:"设计"},{key:"Rocket",icon:h,label:"创业"},{key:"Building2",icon:d,label:"企业"},{key:"Globe",icon:m,label:"网站"},{key:"BookOpen",icon:u,label:"教育"},{key:"Camera",icon:f,label:"影视"},{key:"Music",icon:q,label:"音乐"},{key:"Gamepad2",icon:H,label:"游戏"},{key:"Cpu",icon:S,label:"硬件"},{key:"Coffee",icon:T,label:"餐饮"},{key:"Lightbulb",icon:O,label:"创意"},{key:"Target",icon:j,label:"目标"},{key:"Trophy",icon:z,label:"赛事"},{key:"Heart",icon:I,label:"公益"},{key:"Star",icon:x,label:"收藏"},{key:"Zap",icon:g,label:"快捷"}],Z=[{key:"#3b82f6",label:"蓝色"},{key:"#8b5cf6",label:"紫色"},{key:"#22c55e",label:"绿色"},{key:"#f59e0b",label:"琥珀"},{key:"#ef4444",label:"红色"},{key:"#06b6d4",label:"青色"},{key:"#ec4899",label:"粉色"},{key:"#f97316",label:"橙色"},{key:"#64748b",label:"灰色"},{key:"#0f172a",label:"深黑"}],P=new Map(B.map(a=>[a.key,a.icon]));function J(a){return P.get(a||"")||s}function A(){try{const a=localStorage.getItem("project_tabs");return a?JSON.parse(a):[]}catch{return[]}}function r(a){localStorage.setItem("project_tabs",JSON.stringify(a))}const N=C((a,i)=>({tabs:A(),openTab:(c,l)=>{const{tabs:t}=i();if(t.some(o=>o.id===c))return;const e=[...t,{id:c,name:l}];r(e),a({tabs:e})},closeTab:c=>{const{tabs:l}=i(),t=l.findIndex(y=>y.id===c);if(t===-1)return null;const e=l.filter(y=>y.id!==c);return r(e),a({tabs:e}),e.length===0?null:e[Math.min(t,e.length-1)].id},closeOthers:c=>{const{tabs:l}=i(),t=l.filter(e=>e.id===c);r(t),a({tabs:t})},closeAll:()=>{r([]),a({tabs:[]})},updateTabName:(c,l)=>{const{tabs:t}=i(),e=t.map(o=>o.id===c?{...o,name:l}:o);r(e),a({tabs:e})},reorderTabs:(c,l)=>{const{tabs:t}=i(),e=t.findIndex(k=>k.id===c),o=t.findIndex(k=>k.id===l);if(e===-1||o===-1||e===o)return;const y=[...t],[b]=y.splice(e,1);y.splice(o,0,b),r(y),a({tabs:y})}}));export{B as P,j as T,Z as a,J as g,N as u};
