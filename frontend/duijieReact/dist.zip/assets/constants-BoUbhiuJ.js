import{c as l}from"./index-CvJxT9WM.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=l("AlignLeft",[["path",{d:"M15 12H3",key:"6jk70r"}],["path",{d:"M17 18H3",key:"1amg6g"}],["path",{d:"M21 6H3",key:"1jwq7v"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=l("Flag",[["path",{d:"M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z",key:"i9b6wo"}],["line",{x1:"4",x2:"4",y1:"22",y2:"15",key:"1cm3nv"}]]),o=[{key:"submitted",label:"已提出",color:"var(--brand)",bg:"var(--bg-selected)"},{key:"disputed",label:"待补充",color:"var(--color-warning)",bg:"#fffbeb"},{key:"in_progress",label:"执行中",color:"#7c3aed",bg:"#f5f3ff"},{key:"pending_review",label:"待验收",color:"#ea580c",bg:"#fff7ed"},{key:"review_failed",label:"验收不通过",color:"var(--color-danger)",bg:"#fef2f2"},{key:"accepted",label:"验收通过",color:"var(--color-success)",bg:"#f0fdf4"}],s=Object.fromEntries(o.map(e=>[e.key,{label:e.label,color:e.color,bg:e.bg}])),t={low:{label:"低",color:"gray"},medium:{label:"中",color:"blue"},high:{label:"高",color:"yellow"},urgent:{label:"紧急",color:"red"}},g=e=>/\.(jpg|jpeg|png|gif|webp|bmp|svg)$/i.test(e),i=e=>e<1024?e+"B":e<1048576?(e/1024).toFixed(1)+"KB":(e/1048576).toFixed(1)+"MB";export{r as A,c as F,o as c,i as f,g as i,t as p,s};
