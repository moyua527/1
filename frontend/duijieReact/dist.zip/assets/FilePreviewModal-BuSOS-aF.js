import{c as e,j as r,D as h,X as p}from"./index-BQddm42q.js";import{I as x}from"./image-DulHdlt-.js";import{F as y}from"./file-spreadsheet-BdcOZZ6R.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=e("FileCode",[["path",{d:"M10 12.5 8 15l2 2.5",key:"1tg20x"}],["path",{d:"m14 12.5 2 2.5-2 2.5",key:"yinavb"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z",key:"1mlx9k"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=e("File",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=e("Film",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M7 3v18",key:"bbkbws"}],["path",{d:"M3 7.5h4",key:"zfgn84"}],["path",{d:"M3 12h18",key:"1i2n21"}],["path",{d:"M3 16.5h4",key:"1230mu"}],["path",{d:"M17 3v18",key:"in4fa5"}],["path",{d:"M17 7.5h4",key:"myr1c1"}],["path",{d:"M17 16.5h4",key:"go4c1d"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=e("SquareCheckBig",[["path",{d:"M21 10.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.5",key:"1uzm8b"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=e("Square",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]]),b=t=>t!=null&&t.startsWith("image/")?r.jsx(x,{size:20,color:"var(--color-purple)"}):t!=null&&t.includes("spreadsheet")||t!=null&&t.includes("excel")||t!=null&&t.includes("csv")?r.jsx(y,{size:20,color:"var(--color-success)"}):t!=null&&t.includes("video")?r.jsx(v,{size:20,color:"var(--color-danger)"}):t!=null&&t.includes("json")||t!=null&&t.includes("javascript")||t!=null&&t.includes("html")||t!=null&&t.includes("css")?r.jsx(u,{size:20,color:"var(--color-warning)"}):r.jsx(g,{size:20,color:"var(--brand)"}),j=t=>t<1024?t+" B":t<1024*1024?(t/1024).toFixed(1)+" KB":(t/(1024*1024)).toFixed(1)+" MB";function F({file:t,previewUrl:a,onDownload:c,onClose:n}){var s,o,d,i;return r.jsx("div",{style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.6)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999,padding:16},onClick:n,children:r.jsxs("div",{style:{background:"var(--bg-card)",borderRadius:16,width:"90vw",maxWidth:900,maxHeight:"90vh",display:"flex",flexDirection:"column",overflow:"hidden",boxShadow:"0 8px 32px rgba(0,0,0,0.2)"},onClick:l=>l.stopPropagation(),children:[r.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 20px",borderBottom:"1px solid var(--border-primary)"},children:[r.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[b(t.mime_type),r.jsx("span",{style:{fontSize:14,fontWeight:600,color:"var(--text-primary)",maxWidth:400,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:t.original_name}),r.jsx("span",{style:{fontSize:12,color:"var(--text-tertiary)"},children:j(t.size||0)})]}),r.jsxs("div",{style:{display:"flex",gap:8},children:[r.jsx("button",{onClick:()=>c(t),style:{background:"none",border:"none",cursor:"pointer",padding:4,color:"var(--brand)"},title:"下载",children:r.jsx(h,{size:18})}),r.jsx("button",{onClick:n,style:{background:"none",border:"none",cursor:"pointer",padding:4,color:"var(--text-secondary)"},title:"关闭",children:r.jsx(p,{size:18})})]})]}),r.jsxs("div",{style:{flex:1,overflow:"auto",display:"flex",alignItems:"center",justifyContent:"center",background:"var(--bg-secondary)",minHeight:300},children:[((s=t.mime_type)==null?void 0:s.startsWith("image/"))&&r.jsx("img",{src:a,alt:t.original_name,style:{maxWidth:"100%",maxHeight:"80vh",objectFit:"contain"}}),t.mime_type==="application/pdf"&&r.jsx("iframe",{src:a,style:{width:"100%",height:"80vh",border:"none"},title:t.original_name,sandbox:""}),((o=t.mime_type)==null?void 0:o.startsWith("video/"))&&r.jsx("video",{src:a,controls:!0,style:{maxWidth:"100%",maxHeight:"80vh"}}),((d=t.mime_type)==null?void 0:d.startsWith("audio/"))&&r.jsx("audio",{src:a,controls:!0,style:{margin:40}}),(((i=t.mime_type)==null?void 0:i.startsWith("text/"))||t.mime_type==="application/json")&&r.jsx("iframe",{src:a,style:{width:"100%",height:"80vh",border:"none",background:"var(--bg-card)"},title:t.original_name,sandbox:""})]})]})})}export{v as F,M as S,w as a,u as b,g as c,F as d};
