import{c as e,j as a,D as l,X as p}from"./index-D88rzima.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=e("FileCode",[["path",{d:"M10 12.5 8 15l2 2.5",key:"1tg20x"}],["path",{d:"m14 12.5 2 2.5-2 2.5",key:"yinavb"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z",key:"1mlx9k"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=e("FileSpreadsheet",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M8 13h2",key:"yr2amv"}],["path",{d:"M14 13h2",key:"un5t4a"}],["path",{d:"M8 17h2",key:"2yhykz"}],["path",{d:"M14 17h2",key:"10kma7"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=e("File",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=e("Film",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}],["path",{d:"M7 3v18",key:"bbkbws"}],["path",{d:"M3 7.5h4",key:"zfgn84"}],["path",{d:"M3 12h18",key:"1i2n21"}],["path",{d:"M3 16.5h4",key:"1230mu"}],["path",{d:"M17 3v18",key:"in4fa5"}],["path",{d:"M17 7.5h4",key:"myr1c1"}],["path",{d:"M17 16.5h4",key:"go4c1d"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=e("Image",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=e("SquareCheckBig",[["path",{d:"M21 10.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.5",key:"1uzm8b"}],["path",{d:"m9 11 3 3L22 4",key:"1pflzl"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=e("Square",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]]),k=t=>t!=null&&t.startsWith("image/")?a.jsx(v,{size:20,color:"var(--color-purple)"}):t!=null&&t.includes("spreadsheet")||t!=null&&t.includes("excel")||t!=null&&t.includes("csv")?a.jsx(x,{size:20,color:"var(--color-success)"}):t!=null&&t.includes("video")?a.jsx(u,{size:20,color:"var(--color-danger)"}):t!=null&&t.includes("json")||t!=null&&t.includes("javascript")||t!=null&&t.includes("html")||t!=null&&t.includes("css")?a.jsx(y,{size:20,color:"var(--color-warning)"}):a.jsx(g,{size:20,color:"var(--brand)"}),b=t=>t<1024?t+" B":t<1024*1024?(t/1024).toFixed(1)+" KB":(t/(1024*1024)).toFixed(1)+" MB";function z({file:t,previewUrl:r,onDownload:c,onClose:n}){var s,o,d,i;return a.jsx("div",{style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.6)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999,padding:16},onClick:n,children:a.jsxs("div",{style:{background:"var(--bg-card)",borderRadius:16,width:"90vw",maxWidth:900,maxHeight:"90vh",display:"flex",flexDirection:"column",overflow:"hidden",boxShadow:"0 8px 32px rgba(0,0,0,0.2)"},onClick:h=>h.stopPropagation(),children:[a.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px 20px",borderBottom:"1px solid var(--border-primary)"},children:[a.jsxs("div",{style:{display:"flex",alignItems:"center",gap:8},children:[k(t.mime_type),a.jsx("span",{style:{fontSize:14,fontWeight:600,color:"var(--text-primary)",maxWidth:400,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:t.original_name}),a.jsx("span",{style:{fontSize:12,color:"var(--text-tertiary)"},children:b(t.size||0)})]}),a.jsxs("div",{style:{display:"flex",gap:8},children:[a.jsx("button",{onClick:()=>c(t),style:{background:"none",border:"none",cursor:"pointer",padding:4,color:"var(--brand)"},title:"下载",children:a.jsx(l,{size:18})}),a.jsx("button",{onClick:n,style:{background:"none",border:"none",cursor:"pointer",padding:4,color:"var(--text-secondary)"},title:"关闭",children:a.jsx(p,{size:18})})]})]}),a.jsxs("div",{style:{flex:1,overflow:"auto",display:"flex",alignItems:"center",justifyContent:"center",background:"var(--bg-secondary)",minHeight:300},children:[((s=t.mime_type)==null?void 0:s.startsWith("image/"))&&a.jsx("img",{src:r,alt:t.original_name,style:{maxWidth:"100%",maxHeight:"80vh",objectFit:"contain"}}),t.mime_type==="application/pdf"&&a.jsx("iframe",{src:r,style:{width:"100%",height:"80vh",border:"none"},title:t.original_name,sandbox:""}),((o=t.mime_type)==null?void 0:o.startsWith("video/"))&&a.jsx("video",{src:r,controls:!0,style:{maxWidth:"100%",maxHeight:"80vh"}}),((d=t.mime_type)==null?void 0:d.startsWith("audio/"))&&a.jsx("audio",{src:r,controls:!0,style:{margin:40}}),(((i=t.mime_type)==null?void 0:i.startsWith("text/"))||t.mime_type==="application/json")&&a.jsx("iframe",{src:r,style:{width:"100%",height:"80vh",border:"none",background:"var(--bg-card)"},title:t.original_name,sandbox:""})]})]})})}export{x as F,v as I,f as S,u as a,g as b,M as c,z as d,y as e};
